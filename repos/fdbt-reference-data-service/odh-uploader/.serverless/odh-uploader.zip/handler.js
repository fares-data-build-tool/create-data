"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var s3hook = function (event, context, callback) {
    console.log(JSON.stringify(event));
    console.log(JSON.stringify(context));
    console.log(JSON.stringify(process.env));
};
exports.s3hook = s3hook;
